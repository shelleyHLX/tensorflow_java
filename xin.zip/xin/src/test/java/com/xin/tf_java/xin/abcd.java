package com.xin.tf_java.xin;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import org.apache.commons.io.IOUtils;

import javax.imageio.ImageIO;

import org.tensorflow.Graph;
import org.tensorflow.Operation;
import org.tensorflow.Output;
import org.tensorflow.Session;
import org.tensorflow.Shape;
import org.tensorflow.Tensor;
import org.apache.commons.io.IOUtils; 

public class abcd {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub
		try (Graph graph = new Graph()) {
			byte[] graphBytes = IOUtils.toByteArray(new FileInputStream("model/first.pb"));
			graph.importGraphDef(graphBytes);

			try (Session session = new Session(graph)) {
				Tensor<?> out = session.runner().feed("X", Tensor.create(2.0f)).fetch("results").run().get(0);
				float[] r = new float[1];
				out.copyTo(r);
				System.out.println(r[0]);
			}
		}
	}

}
